Low Frequencies: Typically correspond to bass sounds (e.g kick drums, bass guitars)

Mid Frequencies: Correspond to the body of the sound, such as vocals and guitars.

High Frequencies: Correspond to treble sounds (like cymbals, high-pitched instruments). 